const sqlite3 = require('sqlite3').verbose();
const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();

// Permitir CORS para requisições de diferentes origens
app.use(cors());

// Conectar ao banco de dados SQLite
const db = new sqlite3.Database('./dbcgbr.db', (err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err.message);
  } else {
    console.log('Conectado ao banco de dados!');
  }
});

// Rota para obter produtos do banco de dados
app.get('/produtos', (req, res) => {
  const selectQuery = 'SELECT * FROM produtos';

  db.all(selectQuery, [], (err, rows) => {
    if (err) {
      console.error('Erro ao consultar dados:', err.message);
      return res.status(500).json({ error: err.message });
    }

    // Enviar os dados obtidos como resposta JSON
    res.json(rows);
  });
});

// Iniciar o servidor na porta 3000
app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});

// Fechar a conexão com o banco de dados quando o servidor for encerrado
process.on('SIGINT', () => {
  db.close((err) => {
    if (err) {
      console.error('Erro ao fechar o banco de dados:', err.message);
    } else {
      console.log('Conexão com o banco de dados fechada!');
    }
    process.exit();
  });
});
