const sqlite3 = require('sqlite3').verbose();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser'); // Para lidar com dados POST
const app = express();

// Configuração do CORS para permitir requisições de uma origem específica
const corsOptions = {
    origin: 'http://127.0.0.1:5500', // Substitua pelo endereço correto do seu frontend
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type'],
};

// Permitir CORS com a configuração especificada
app.use(cors(corsOptions));

// Usar o body-parser para lidar com dados JSON no corpo da requisição
app.use(bodyParser.json());

// Conectar ao banco de dados SQLite
const db = new sqlite3.Database('./dbcgbr.db', (err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err.message);
  } else {
    console.log('Conectado ao banco de dados!');
  }
});

// Rota para obter produtos do banco de dados
app.get('/produtos', (req, res) => {
  const selectQuery = 'SELECT * FROM produtos';

  db.all(selectQuery, [], (err, rows) => {
    if (err) {
      console.error('Erro ao consultar dados:', err.message);
      return res.status(500).json({ error: err.message });
    }

    // Enviar os dados obtidos como resposta JSON
    res.json(rows);
  });
});

// Rota para cadastrar um novo produto
app.post('/produtos', (req, res) => {
  const { nome, modelo, cor, marca, imagem, preco, descricao } = req.body;  // Dados enviados pelo frontend

  // Inserir os dados no banco de dados
  const insertQuery = 'INSERT INTO produtos (nome, modelo, cor, marca, imagem, descricao, preco) VALUES (?, ?, ?, ?, ?, ?, ?)';

  db.run(insertQuery, [nome, modelo, cor, marca, imagem, descricao, preco], function(err) {
    if (err) {
      console.error('Erro ao inserir dados:', err.message);
      return res.status(500).json({ error: err.message });
    }

    // Responder com sucesso
    res.status(201).json({ message: 'Produto cadastrado com sucesso!', id: this.lastID });
  });
});

// Iniciar o servidor na porta 3000
app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});

// Fechar a conexão com o banco de dados quando o servidor for encerrado
process.on('SIGINT', () => {
  db.close((err) => {
    if (err) {
      console.error('Erro ao fechar o banco de dados:', err.message);
    } else {
      console.log('Conexão com o banco de dados fechada!');
    }
    process.exit();
  });
});
