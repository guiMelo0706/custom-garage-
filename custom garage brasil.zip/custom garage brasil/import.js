const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');

// Conectar ao banco de dados
const db = new sqlite3.Database('./dbcgbr.db', (err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err.message);
  } else {
    console.log('Conectado ao banco de dados!');
  }
});

const selectQuery = `
select * from produtos
`;

db.all(selectQuery, [], (err, rows) => {  // .all é usado para retornar várias linhas
  if (err) {
    console.error('Erro ao consultar dados:', err.message);
  } else {
    // Exibir os dados no console
    console.log('Produtos encontrados:', rows);
    
    // Escrever os dados em um arquivo JSON
    const filePath = './produtos.json';
    
    // Usar o método fs.writeFileSync() para escrever os dados no arquivo
    fs.writeFileSync(filePath, JSON.stringify(rows, null, 2), 'utf-8');
    console.log(`Dados salvos no arquivo ${filePath}`);
  }
  
  // Fechar a conexão com o banco de dados após a operação
  db.close((err) => {
    if (err) {
      console.error('Erro ao fechar o banco de dados:', err.message);
    } else {
      console.log('Conexão com o banco de dados fechada!');
    }
  });
});
